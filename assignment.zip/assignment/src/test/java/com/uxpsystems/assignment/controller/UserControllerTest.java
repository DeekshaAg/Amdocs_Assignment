package com.uxpsystems.assignment.controller;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.Matcher;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.uxpsystems.assignment.dao.User;
import com.uxpsystems.assignment.service.UserAuthenticationService;
import com.uxpsystems.assignment.service.UserService;

@RunWith(SpringRunner.class)
@WebMvcTest(UserController.class)

@WithMockUser(username="Admin",roles={"USER","ADMIN"})
public class UserControllerTest {
	
	@Autowired
	private MockMvc mvc;
	
	

	@MockBean
	private UserService userService;
	
	@MockBean
	private UserAuthenticationService userAuthenticationService;
	
	@Before
	public void init() {
		
		User user1 = new User("User1","Password","Activated");
		user1.setId(1L);
		User user2 = new User("User2","Password","Activated");
		user2.setId(2L);
		List<User> userList = new ArrayList<User>(); 
		userList.add(user1);
		userList.add(user2);
		
		Mockito.when(userService.getAllUsers()).thenReturn(userList);
		Mockito.when(userService.getUser(1L)).thenReturn(user1);
		Mockito.when(userService.createUser(user1)).thenReturn(user1);
		Mockito.when(userService.updateUser(user1, 1L)).thenReturn(1);
	}
	
	@Test
	public void whenGetAllUsers_ReturnUserList() throws Exception {
		
		mvc.perform(get("/assignment"))
		.andExpect(status().isOk())
		.andExpect(view().name("index"))
		.andExpect(model().attribute("userList", Matchers.hasSize(2)))
		.andExpect(model().attribute("userList", Matchers.hasItem(
				Matchers.allOf(
                        Matchers.hasProperty("id", is(1L)),
                        Matchers.hasProperty("username", is("User1")),
                        Matchers.hasProperty("password", is("Password")),
                        Matchers.hasProperty("status", is("Activated"))
                )
        )))
        .andExpect(model().attribute("userList", Matchers.hasItem(
        		Matchers.allOf(
                		Matchers.hasProperty("id", is(2L)),
                		Matchers.hasProperty("username", is("User2")),
                		Matchers.hasProperty("password", is("Password")),
                		Matchers.hasProperty("status", is("Activated"))
                )
        )));
		
		verify(userService, times(1)).getAllUsers();
	}
	
	@Test
	public void whenGetUser_ReturnUser() throws Exception{
		
		User user1 = new User("User1","Password","Activated");
		user1.setId(1L);
		
		ModelAndView mav=mvc.perform(get("/get/{userid}", 1L)).andReturn().getModelAndView();
		System.out.println(mav);	
		assertEquals(mav.getViewName(),"view_user");
		assertEquals(mav.getModel().get("user").toString(),user1.toString());
		verify(userService, times(1)).getUser(1L);
	}
	
	@Test
	public void whenUpdateUser_RedirectToUpdateUserPage() throws Exception {
		
		User user1 = new User("User1","Password","Activated");
		user1.setId(1L);
		
		ModelAndView mav=mvc.perform(get("/update/{userid}", 1L)).andReturn().getModelAndView();
		
		assertEquals(mav.getViewName(),"update_user");
		assertEquals(mav.getModel().get("user").toString(),user1.toString());
		verify(userService, times(1)).getUser(1L);
		
	}
	
	@Test
	public void whenPostOnUpdateUser_ReturntoHomePageOnSuccess() throws Exception{
		User user1 = new User("UpdatedUser","Password","Activated");
		user1.setId(1L);
		mvc.perform(post("/update")
				.param("id", user1.getId().toString())
				.param("username", user1.getUsername())
				.param("password", user1.getPassword())
				.param("status", user1.getStatus())
				.sessionAttr("user", user1))
		.andExpect(status().is3xxRedirection())
		.andExpect(view().name("redirect:/assignment"))
		.andExpect(redirectedUrl("/assignment"));
		
	}
	
	@Test
	public void whenCreateUser_ReturnToHomePage() throws Exception{
		User user1 = new User("NewUser","Password","Activated");
		user1.setId(1L);
		mvc.perform(post("/user")
				.param("id", user1.getId().toString())
				.param("username", user1.getUsername())
				.param("password", user1.getPassword())
				.sessionAttr("user", user1))
		.andExpect(status().is3xxRedirection())
		.andExpect(view().name("redirect:/assignment"))
		.andExpect(redirectedUrl("/assignment"));
	}
	
	@Test
	public void whenDeleteUser_ReturnToHomePageOnSuccess() throws Exception{
		
		mvc.perform(get("/delete/{userid}",1L))
		.andExpect(status().is3xxRedirection())
		.andExpect(view().name("redirect:/assignment"))
		.andExpect(redirectedUrl("/assignment"));
		
		verify(userService, times(1)).deleteUser(1L);
	}
	
	@Test
	public void whenNewUserClicked_ReturnNewUserPage() throws Exception{
		
		mvc.perform(get("/new"))
		.andExpect(status().isOk())
		.andExpect(view().name("new_user"));
	}

}
