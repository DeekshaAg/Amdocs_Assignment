package com.uxpsystems.assignment.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.any;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.uxpsystems.assignment.dao.User;
import com.uxpsystems.assignment.dao.UserRepository;

@RunWith(SpringRunner.class)
public class UserServiceTest {
	
	@TestConfiguration
	static class UserServiceTestConfiguration{
		
		@Bean
		public UserService userService() {
			return new UserService();
		}
	}
	
	@Autowired
	private UserService userService;
	
	@MockBean
	private UserRepository userRepository;
	
	@Before
	public void init() {
		User user1 = new User("User1","Password","Activated");
		user1.setId(1L);
		Optional<User> result1 = Optional.of(user1);
		User user2 = new User("User2","Password","Activated");
		user2.setId(2L);
		Optional<User> result2 = Optional.of(user2);
		List<User> userList = new ArrayList<User>(); 
		userList.add(user1);
		userList.add(user2);
		Mockito.when(userRepository.findById(1L)).thenReturn(result1);
		Mockito.when(userRepository.findAll()).thenReturn(userList);
		Mockito.when(userRepository.save(Mockito.any(User.class))).thenReturn(user1);
		Mockito.when(userRepository.updateUserById("UpdateUser1", "UpdatedPass", "Activated", 1L)).thenReturn(1);
	}
	
	@Test
	public void whenValidId_ThenEmployeeFound(){
		Long id = 1L;
		User retrieved_user = userService.getUser(id);
		
		assertEquals("User1", retrieved_user.getUsername());
		assertEquals("Password",retrieved_user.getPassword());
		assertEquals("Activated", retrieved_user.getStatus());
	}
	
	@Test
	public void whenValidUpdatedUser_ThenReturnCountOfRowsUpdated() {
		User user =  new User("UpdateUser1", "UpdatedPass", "Activated");
		int count = userService.updateUser(user,1L);
		assertEquals(1,count);
		verify(userRepository,times(1)).updateUserById("UpdateUser1", "UpdatedPass", "Activated", 1L);
	}
	
	@Test
	public void whenGetAllUsers_ThenReturnUserList() {
		
		User user1 = new User("User1","Password","Activated");
		user1.setId(1L);
		User user2 = new User("User2","Password","Activated");
		user2.setId(2L);
		List<User> expected_users = new ArrayList<User>();
		expected_users.add(user1);
		expected_users.add(user2);
		List<User> users = userService.getAllUsers();
		
		assertThat(users.containsAll(expected_users));
	}
	
	@Test
	public void whenValidUser_CreateUser() {
		User user1 = new User("User1","Password","Activated");
		user1.setId(1L);
		System.out.println(user1);
		User created_user=userService.createUser(user1);
		assertEquals(user1.getUsername(),created_user.getUsername());
		assertEquals(user1.getPassword(),created_user.getPassword());
		assertEquals(user1.getStatus(),created_user.getStatus());
		
		verify(userRepository, times(1)).save(user1);
	}
	
	@Test
	public void whenValidUserId_thenDeleteUser() {
		
		userService.deleteUser(1L);
		verify(userRepository, times(1)).deleteById(1L);
	}
}
