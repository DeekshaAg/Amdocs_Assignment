package com.uxpsystems.assignment.dao;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataJpaTest
public class UserRepositoryTest {
	
	@Autowired
    private TestEntityManager entityManager;
	
	@Autowired
	private UserRepository userRepository;
	
	@Test
	public void whenFindById_thenReturnUser() {
		
		//given
		
		User user = new User("User1", "Password", "Activated");
		User persisted_user = entityManager.persist(user);
		entityManager.flush();
		
		//when
		User retrieved_user = userRepository.findById(persisted_user.getId()).get();
		
		//then
		assertThat(persisted_user.getId().equals(retrieved_user.getId()));
	}
	
	@Test
	public void whenFindByUsername_thenReturnUser() {
		
		//given
		User user = new User("User1", "Password", "Activated");
		entityManager.persist(user);
		entityManager.flush();
		
		//when
		User retieved_user = userRepository.findByUsername("User1");
		
		//then
		assertThat(user.getUsername().equals(retieved_user.getUsername()));
	}
	
	@Test
	public void whenUpdateUserById_thenReturnCountOfRowsUpdated() {
		
		//given
		User user = new User("User1", "Password", "Activated");
		User persisted_user = entityManager.persist(user);
		entityManager.flush();
		
		//when
		int numberOfRowsUpdated = userRepository.updateUserById("User1", "Password@123", "Deactivated", persisted_user.getId());
		
		//then
		assertThat(numberOfRowsUpdated == 1);
	}

	@Test
	public void whenFindAll_thenReturnUserList() {
		
		//given
		User user1 = new User("User1", "Password", "Activated");
		entityManager.persist(user1);
		entityManager.flush();
		User user2 = new User("User2", "Password", "Deactivated");
		entityManager.persist(user2);
		entityManager.flush();
		List<User> persisted_users = new ArrayList<User>();
		persisted_users.add(user1);
		persisted_users.add(user2);
		
		//when
		List<User> users = new ArrayList<User>();
		userRepository.findAll().forEach(users::add);
		
		//then
		assertThat(users.containsAll(persisted_users));
		
	}
	
	@Test
	public void whenSaveUser_thenReturnUser() {
		
		//when
		User user = new User("User1", "Password", "Activated");
		User saved_user = userRepository.save(user);
		
		//then
		assertThat(saved_user.equals(user));
		
	}
}
