package com.uxpsystems.assignment.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class UserAuthenticationDetails implements UserDetails {
	
	private String username;
	private String password;
	private Boolean active;
	private List<GrantedAuthority> authorities;

	public UserAuthenticationDetails() {
		super();
	}


	public UserAuthenticationDetails(User user) {
		// TODO Auto-generated constructor stub
		this.username = user.getUsername();
		this.password = user.getPassword();
		if(user.getStatus().equals("Activated"))
			this.active = true;
		else
			this.active = false;
		
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		this.authorities= new ArrayList<GrantedAuthority>();
		if(this.username.startsWith("Admin"))
			this.authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
		else
			this.authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
		return this.authorities;
	}
	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return this.password;
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return this.username;
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return this.active;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return this.active;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return this.active;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return this.active;
	}

}
