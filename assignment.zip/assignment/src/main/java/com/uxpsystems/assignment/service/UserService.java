package com.uxpsystems.assignment.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.uxpsystems.assignment.dao.User;
import com.uxpsystems.assignment.dao.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;
	
	public User getUser(Long id) {
		User user = new User();
		try {
			user = userRepository.findById(id).get();
			
		}catch(IllegalArgumentException e) {
			return null;
		}catch(NoSuchElementException e) {
			return null;
		}
		return user;
	}
	
	public User createUser(User user) {
		User user1 = userRepository.save(user);
		
		return user1;
	}
	
	public int updateUser(User user, Long id) {
		return userRepository.updateUserById(user.getUsername(), user.getPassword(),user.getStatus(), id);
	}
	
	public void deleteUser(Long id) {
		userRepository.deleteById(id);
	}

	public java.util.List<User> getAllUsers() {
		// TODO Auto-generated method stub
		java.util.List<User> users = new ArrayList<>();
		try {
			userRepository.findAll().forEach(users::add);
		}catch(NullPointerException e) {
			return users;
		}
		return users;
	}
}
