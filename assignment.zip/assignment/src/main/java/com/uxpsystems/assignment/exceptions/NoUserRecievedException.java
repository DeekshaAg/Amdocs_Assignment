package com.uxpsystems.assignment.exceptions;

public class NoUserRecievedException extends Exception {
	
	public NoUserRecievedException(String message) {
		super(message);
	}

}
