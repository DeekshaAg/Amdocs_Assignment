package com.uxpsystems.assignment.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.uxpsystems.assignment.dao.User;
import com.uxpsystems.assignment.exceptions.NoUserRecievedException;
import com.uxpsystems.assignment.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value="/assignment")
	public String getHomePage(Model model) {
		try {
		List<User> userList = userService.getAllUsers();
		model.addAttribute("userList",userList);
		}catch(Exception e) {
			return "error";
		}
		return "index";
	}
	
	@RequestMapping("/get/{userid}")
	public ModelAndView getUserViewPage(@PathVariable Long userid) {
		ModelAndView mav = new ModelAndView("view_user");
		try {
		    User user = userService.getUser(userid);
		    if(user == null)
		    	throw new NoUserRecievedException("No user recieved for this id");
			mav.addObject("user",user); 
		}catch(NoUserRecievedException e) {
			mav.setViewName("error-404");
		}catch(Exception e) {
			mav.setViewName("error");
		}
		
	    return mav;
	}
	
	
	@RequestMapping(value="/user", method=RequestMethod.GET)
	public String getUser() {
		return "redirect:/assignment";
	}
	
	@RequestMapping(value="/new")
	public String showNewUserPage(Model model) {
		User user = new User();
		model.addAttribute("user",user);
		return "new_user";
	}
	
	@RequestMapping(value="/user", method=RequestMethod.POST)
	public String createUser(@Valid @ModelAttribute("user") User user, BindingResult result) {
		try {
			if (result.hasErrors()) {
	            return "new_user";
	            }
			user.setStatus("Activated");
			userService.createUser(user);
		}catch(Exception e) {
			return "error-500";
		}
		return "redirect:/assignment";
	}
	
	@RequestMapping(value="/update/{id}")
	public ModelAndView showUpdateUserPage(@PathVariable Long id) {
		ModelAndView mav = new ModelAndView("update_user");
		try {
			User user = userService.getUser(id);
			if(user == null)
		    	throw new NoUserRecievedException("No user recieved for this id");
			mav.addObject("user",user);
		}catch(NoUserRecievedException e) {
			mav.setViewName("error-404");
		}catch(Exception e) {
			mav.setViewName("error");
		}
		
		return mav;
	}
	
	@RequestMapping(value="/update", method=RequestMethod.POST)
	public String updateUser(@Valid @ModelAttribute("user") User user, BindingResult result) {
		 if (result.hasErrors()) {
            return "update_user";
            }
		 try {
		 userService.updateUser(user, user.getId());
		 }catch(Exception e) {
			 return "error-500";
		 }
		 return "redirect:/assignment";
	}
	
	@RequestMapping(value="/delete/{userid}",method=RequestMethod.GET)
	public String deleteUser(@PathVariable Long userid) {
		try {
			userService.deleteUser(userid);
		}catch(Exception e) {
			return "error-500";
		}
		return "redirect:/assignment";
	}
	

}
