1. The application is accessible on : http://localhost:9090/assignment
2. The application has an ADMIN role user: "Admin" with Password: "Pass", this user is created through the data.sql file present in /resources folder
3. The View Details functionality is accessible to both USER and ADMIN role users.
4. THe NEW user, Update user and Delete user functionality is only accessible for ADMIN role users. 
5. While creating a new user if the username is prefixed with "Admin" then the user will automatically get the ADMIn role.
	All other user with have USER role. 

# The application runs on tomcat server.